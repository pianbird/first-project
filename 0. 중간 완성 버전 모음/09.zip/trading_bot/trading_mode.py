import os
from typing import Dict, Any, Optional

VALID_TRADING_MODES = {"MOCK", "REAL", "DISABLED"}

MODE_TEXT = {
    "MOCK": "모의투자",
    "REAL": "실전투자",
    "DISABLED": "매매중지"
}

class InvalidTradingModeError(ValueError):
    """트레이딩 모드가 유효하지 않을 때 발생하는 예외"""
    pass

class ModeEndpointMismatchError(RuntimeError):
    """REAL/MOCK 모드와 엔드포인트 URL이 불일치할 때 발생하는 예외"""
    pass

class TradingModeManager:
    """
    Trading Mode 중앙 Single Source of Truth 관리 객체
    - MOCK, REAL, DISABLED 세 모드만 허용
    - 각 객체(WebTradingEngine, OrderManager, KiwoomClient)가 동기화되어 동일 상태 공유
    - REAL/MOCK 엔드포인트 수신 강제 점검
    - 주문 직전 최후 안전 Gate 검사
    """

    def __init__(self, initial_mode: str = "MOCK"):
        self._mode = self.validate_and_normalize_mode(initial_mode)

    @staticmethod
    def validate_and_normalize_mode(mode_input: Any) -> str:
        """
        트레이딩 모드 검증 및 정규화
        지원하는 모드: MOCK, REAL, DISABLED
        잘못된 값(TEST, INVALID, None, 빈문자열 등)은 거부
        """
        if not mode_input or not isinstance(mode_input, str):
            raise InvalidTradingModeError(f"유효하지 않은 트레이딩 모드 입력: {mode_input}")

        normalized = mode_input.strip().upper()
        if normalized not in VALID_TRADING_MODES:
            raise InvalidTradingModeError(
                f"지원하지 않는 트레이딩 모드입니다: '{mode_input}'. "
                f"허용된 모드: {sorted(list(VALID_TRADING_MODES))}"
            )

        return normalized

    def set_mode(self, new_mode: str) -> str:
        """모드 변경 (검증 포함, 입력값 그대로 정규화 적용)"""
        validated = self.validate_and_normalize_mode(new_mode)
        self._mode = validated
        return self._mode

    def get_mode(self) -> str:
        return self._mode

    @property
    def mode(self) -> str:
        return self._mode

    @mode.setter
    def mode(self, value: str):
        self._mode = self.validate_and_normalize_mode(value)

    def get_mode_text(self) -> str:
        """Dashboard 표시용 한국어 모드 명칭 반환 (NameError 방지)"""
        return MODE_TEXT.get(self._mode, "알 수 없음")

    def validate_endpoint_isolation(self, api_url: str, is_mock_endpoint: bool):
        """
        P0-1: REAL/MOCK/DISABLED 서버 이중 격리 강제 검사
        """
        if self._mode == "DISABLED":
            raise ModeEndpointMismatchError("CRITICAL ERROR: DISABLED 모드에서는 모든 API 주문 호출이 금지됩니다.")

        url_lower = (api_url or "").lower()

        if self._mode == "REAL":
            if is_mock_endpoint or "mock" in url_lower or "simulation" in url_lower:
                raise ModeEndpointMismatchError(
                    f"CRITICAL ERROR: REAL 모드에서 Mock API 엔드포인트({api_url})가 감지되었습니다. "
                    "실전 매매를 즉시 중단합니다."
                )

        if self._mode == "MOCK":
            if not is_mock_endpoint or (("api.kiwoom.com" in url_lower or "openapi.kiwoom.com" in url_lower) and "mock" not in url_lower):
                raise ModeEndpointMismatchError(
                    f"CRITICAL ERROR: MOCK 모드에서 REAL API 엔드포인트({api_url})가 감지되었습니다. "
                    "모의 매매를 즉시 중단합니다."
                )

    def can_place_order(self) -> bool:
        """주문 직전 매매 가능 여부 검사"""
        if self._mode == "DISABLED":
            return False
        return self._mode in ("MOCK", "REAL")
