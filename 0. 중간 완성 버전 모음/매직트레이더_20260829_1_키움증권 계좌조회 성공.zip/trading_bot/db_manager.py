import os
import sqlite3
import time
import json


from typing import Dict, Any, List, Optional

class DBManager:
    """
    SQLite3 기반 주문 내역, 잔고 포지션 및 트레이딩 로그 영속성 관리자
    """

    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), "data", "trading.db")

        self.db_path = db_path
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """테이블 스키마 자동 생성"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 1. 주문 내역 테이블 (orders)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                stock_code TEXT NOT NULL,
                stock_name TEXT NOT NULL,
                side TEXT NOT NULL,
                ord_dvsn TEXT DEFAULT '03',
                price INTEGER DEFAULT 0,
                qty INTEGER NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                executed_at TEXT
            )
            """)

            # 2. 잔고 포지션 테이블 (positions)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS positions (
                stock_code TEXT PRIMARY KEY,
                stock_name TEXT NOT NULL,
                qty INTEGER NOT NULL,
                avg_price INTEGER NOT NULL,
                current_price INTEGER DEFAULT 0,
                pnl INTEGER DEFAULT 0,
                pnl_rate REAL DEFAULT 0.0,
                updated_at TEXT NOT NULL
            )
            """)

            # 3. 트레이딩 로그 테이블 (trade_logs)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS trade_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL
            )
            """)

            # 4. 그리드 전략 설정 테이블 (grid_configs)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS grid_configs (
                stock_code TEXT PRIMARY KEY,
                config_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """)

            # 5. 그리드 런타임 상태 테이블 (grid_states)
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS grid_states (
                stock_code TEXT PRIMARY KEY,
                current_step INTEGER DEFAULT 0,
                target_qty INTEGER DEFAULT 0,
                actual_qty INTEGER DEFAULT 0,
                is_blackswan_halt INTEGER DEFAULT 0,
                consecutive_ma5_above INTEGER DEFAULT 0,
                recycle_mode INTEGER DEFAULT 0,
                updated_at TEXT NOT NULL
            )
            """)
            conn.commit()

    def save_grid_config(self, config_dict: Dict[str, Any]):
        """그리드 전략 설정 저장"""
        code = config_dict.get("stock_code")
        json_str = json.dumps(config_dict, ensure_ascii=False)
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO grid_configs (stock_code, config_json, updated_at)
            VALUES (?, ?, ?)
            """, (code, json_str, now_str))
            conn.commit()

    def get_grid_config(self, stock_code: str) -> Optional[Dict[str, Any]]:
        """그리드 전략 설정 조회"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT config_json FROM grid_configs WHERE stock_code = ?", (stock_code,))
            row = cursor.fetchone()
            if row:
                return json.loads(row["config_json"])
            return None

    def save_grid_state(self, stock_code: str, state_obj: Any):
        """그리드 런타임 상태 저장"""
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO grid_states
            (stock_code, current_step, target_qty, actual_qty, is_blackswan_halt, consecutive_ma5_above, recycle_mode, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                stock_code,
                getattr(state_obj, "current_step", 0),
                getattr(state_obj, "target_qty", 0),
                getattr(state_obj, "actual_qty", 0),
                1 if getattr(state_obj, "is_blackswan_halt", False) else 0,
                getattr(state_obj, "consecutive_ma5_above", 0),
                1 if getattr(state_obj, "recycle_mode", False) else 0,
                now_str
            ))
            conn.commit()

    def record_order(self, order_data: Dict[str, Any]):
        """주문 정보 추가"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO orders 
            (order_id, stock_code, stock_name, side, ord_dvsn, price, qty, status, created_at, executed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                order_data.get("order_id"),
                order_data.get("stock_code"),
                order_data.get("stock_name", order_data.get("stock_code")),
                order_data.get("order_type", "BUY"),
                order_data.get("ord_dvsn", "03"),
                order_data.get("price", 0),
                order_data.get("qty", 0),
                order_data.get("status", "ACCEPTED"),
                order_data.get("timestamp", time.strftime("%Y-%m-%d %H:%M:%S")),
                order_data.get("executed_at")
            ))
            conn.commit()

    def update_order_status(self, order_id: str, status: str, executed_at: Optional[str] = None):
        """주문 체결/취소 상태 업데이트"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            now_str = executed_at or time.strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("""
            UPDATE orders SET status = ?, executed_at = ? WHERE order_id = ?
            """, (status, now_str, order_id))
            conn.commit()

    def upsert_position(self, pos_data: Dict[str, Any]):
        """포지션 갱신 (매수 체결 시 추가/갱신)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO positions
            (stock_code, stock_name, qty, avg_price, current_price, pnl, pnl_rate, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                pos_data.get("stock_code"),
                pos_data.get("stock_name", pos_data.get("stock_code")),
                pos_data.get("qty", 0),
                pos_data.get("avg_price", 0),
                pos_data.get("current_price", 0),
                pos_data.get("pnl", 0),
                pos_data.get("pnl_rate", 0.0),
                time.strftime("%Y-%m-%d %H:%M:%S")
            ))
            conn.commit()

    def remove_position(self, stock_code: str):
        """포지션 삭제 (전량 청산 시)"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM positions WHERE stock_code = ?", (stock_code,))
            conn.commit()

    def get_active_positions(self) -> List[Dict[str, Any]]:
        """현재 보유 포지션 조회"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM positions WHERE qty > 0")
            rows = cursor.fetchall()
            return [dict(r) for r in rows]

    def get_recent_orders(self, limit: int = 20) -> List[Dict[str, Any]]:
        """최근 주문 내역 조회"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            return [dict(r) for r in rows]

    def get_today_trade_count(self, stock_code: Optional[str] = None) -> int:
        """당일 체결 완료/전송된 주문 횟수 조회"""
        today_str = time.strftime("%Y-%m-%d")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if stock_code:
                cursor.execute("""
                SELECT COUNT(*) FROM orders 
                WHERE stock_code = ? AND created_at >= ?
                """, (stock_code, f"{today_str} 00:00:00"))
            else:
                cursor.execute("""
                SELECT COUNT(*) FROM orders 
                WHERE created_at >= ?
                """, (f"{today_str} 00:00:00",))
            return cursor.fetchone()[0]

    def log_event(self, level: str, message: str):
        """트레이딩 이벤트 로그 기록"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            now_str = time.strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute("""
            INSERT INTO trade_logs (timestamp, level, message) VALUES (?, ?, ?)
            """, (now_str, level.upper(), message))
            conn.commit()

    def get_recent_logs(self, limit: int = 30) -> List[Dict[str, Any]]:
        """최근 시스템 로그 조회"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trade_logs ORDER BY id DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
