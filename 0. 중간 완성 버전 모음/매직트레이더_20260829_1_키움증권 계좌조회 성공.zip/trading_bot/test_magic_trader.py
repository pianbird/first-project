import os
import sys
import unittest

# trading_bot 경로 모듈 검색 등록
base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from grid_strategy import generate_auto_grid_config, GridConfig, GridStep, GridState
from magic_trade_engine import MagicTradeEngine
from db_manager import DBManager
from kiwoom_client import KiwoomRESTClient
from order_guard import OrderGuard

class TestMagicTraderStrategy(unittest.TestCase):
    """
    그리드 기반 무한 순환매매(MagicTrader) 전략 매매 엔진 단위 테스트
    """

    def setUp(self):
        self.config_path = os.path.join(base_dir, "config.json")
        self.db = DBManager(os.path.join(base_dir, "data", "test_trading.db"))
        self.kiwoom = KiwoomRESTClient(config_path=self.config_path)
        self.order_guard = OrderGuard(self.kiwoom.config)
        self.engine = MagicTradeEngine()

        # 테스트용 삼성전자 20차 그리드 자동 생성 (기준가: 70,000원, 청산가: 80,000원)
        self.stock_code = "005930"
        self.grid_cfg = generate_auto_grid_config(
            stock_code=self.stock_code,
            stock_name="삼성전자",
            base_price=70000,
            exit_price=80000,
            num_steps=20,
            step_pct=1.5,
            step_qty=1
        )
        self.engine.register_grid_config(self.grid_cfg, self.db)

    def test_auto_grid_generation(self):
        """20차 그리드 수량 및 호가 단위 보정 테스트"""
        self.assertEqual(len(self.grid_cfg.grid_steps), 20)
        self.assertEqual(self.grid_cfg.exit_price, 80000)
        
        # 1차 매수 가격이 기준가(70,000원)보다 하락했는지 검증
        first_step = self.grid_cfg.grid_steps[0]
        self.assertLess(first_step.price, 70000)
        self.assertEqual(first_step.target_total_qty, 1)

        # 2차 매수 누적 수량이 2인지 검증
        second_step = self.grid_cfg.grid_steps[1]
        self.assertEqual(second_step.target_total_qty, 2)

    def test_quantity_reconciliation(self):
        """수량 자동 보정 공식 (필요 수량 = 목표 수량 - 실제 보유 수량) 검증"""
        state = self.engine.get_grid_state(self.stock_code)
        
        # 2차 가격에 도달했을 때 (목표 수량 2주)
        second_price = self.grid_cfg.grid_steps[1].price
        
        # 현재 보유 0주일 때 -> 필요 수량 2주 매수
        eval1 = self.engine.evaluate_stock(
            stock_code=self.stock_code,
            current_price=second_price,
            daily_candles=[],
            actual_position_qty=0,
            db=self.db,
            kiwoom=self.kiwoom,
            order_guard=self.order_guard
        )
        self.assertEqual(eval1.get("action"), "GRID_BUY")

    def test_blackswan_filter_recovery(self):
        """블랙스완 방어: 5일선 2회 연속 안착 후 매수 재개 테스트"""
        # 블랙스완 플래그 활성화
        self.engine.trigger_blackswan_halt(self.stock_code, self.db)
        state = self.engine.get_grid_state(self.stock_code)
        self.assertTrue(state.is_blackswan_halt)

        # 5일선 이하로 종가가 형성된 봉 데이터 (매수 금지 유지)
        bad_candles = [
            {"close_price": 60000}, {"close_price": 61000}, {"close_price": 62000},
            {"close_price": 63000}, {"close_price": 64000}, {"close_price": 65000}
        ]
        can_buy1 = self.engine.evaluate_blackswan_filter(self.stock_code, bad_candles)
        self.assertFalse(can_buy1)

        # 종가가 5일선 위에 2회 연속 안착한 봉 데이터 (매수 해제)
        good_candles = [
            {"close_price": 75000}, {"close_price": 74000}, {"close_price": 70000},
            {"close_price": 68000}, {"close_price": 67000}, {"close_price": 66000}
        ]
        can_buy2 = self.engine.evaluate_blackswan_filter(self.stock_code, good_candles)
        self.assertTrue(can_buy2)
        self.assertFalse(state.is_blackswan_halt)

def print_magic_trader_test_summary():
    """그리드 무한 순환매매 전략 테스트 결과 가독성 출력"""
    config_path = os.path.join(base_dir, "config.json")
    client = KiwoomRESTClient(config_path=config_path)
    engine = MagicTradeEngine()

    grid_cfg = generate_auto_grid_config(
        stock_code="005930",
        stock_name="삼성전자",
        base_price=70000,
        exit_price=80000,
        num_steps=10,
        step_pct=1.5,
        step_qty=1
    )
    engine.register_grid_config(grid_cfg)

    print("=" * 65)
    print(" [trading_bot] 매직 트레이더 (MagicTrader) 그리드 매매 시뮬레이션")
    print("=" * 65)
    print(f"[*] 대상 종목   : {grid_cfg.stock_name} ({grid_cfg.stock_code})")
    print(f"[*] 최종 청산가 : {grid_cfg.exit_price:,} 원")
    print(f"[*] 그리드 차수 : 총 {grid_cfg.max_steps} 차")
    print(f"[*] 최대 투자금 : {grid_cfg.max_capital:,} 원")
    print("-" * 65)
    print(" [차수별 그리드 설정 요약 (1~5차)]")
    for s in grid_cfg.grid_steps[:5]:
        print(f"  - {s.step:2d}차 매수가: {s.price:,}원 | 단계 수량: {s.step_qty}주 | 누적 목표: {s.target_total_qty}주")
    print("=" * 65)

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    print_magic_trader_test_summary()
    print("\n[매직 트레이더 단위 테스트 실행]")
    unittest.main(argv=[sys.argv[0]], exit=False)
