import os
import sys
import unittest

# trading_bot 경로 모듈 검색 등록
base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from kiwoom_client import KiwoomRESTClient

class TestSamsungPriceFetch(unittest.TestCase):
    """
    trading_bot 모듈의 KiwoomRESTClient를 이용한 삼성전자(005930) 주가 조회 테스트
    """

    def setUp(self):
        config_path = os.path.join(base_dir, "config.json")
        self.client = KiwoomRESTClient(config_path=config_path)
        self.samsung_code = "005930"

    def test_get_access_token(self):
        """키움 REST API OAuth2 토큰 발급 테스트"""
        if self.client.is_credentials_valid():
            token = self.client.get_access_token()
            self.assertIsNotNone(token)
            self.assertTrue(len(token) > 0, "발급된 토큰 문자열이 비어있습니다.")

    def test_fetch_samsung_stock_price(self):
        """삼성전자(005930) 실시간 주가 정보 조회 데이터 유효성 검증"""
        price_info = self.client.get_stock_price(self.samsung_code)

        if self.client.is_credentials_valid():
            self.assertTrue(price_info.get("success"), f"주가 조회 실패: {price_info.get('error')}")
            self.assertEqual(price_info.get("code"), "005930")
            self.assertIn("삼성전자", price_info.get("name", ""))

            current_price = price_info.get("current_price", 0)
            self.assertIsInstance(current_price, int)
            self.assertGreater(current_price, 0, "삼성전자 현재가는 0보다 커야 합니다.")

            prev_open = price_info.get("prev_open_price", 0)
            self.assertGreater(prev_open, 0, "삼성전자 전일 시가는 0보다 커야 합니다.")

def print_samsung_price_summary():
    """삼성전자 주가 조회 결과를 가독성 있게 화면에 출력하는 함수"""
    config_path = os.path.join(base_dir, "config.json")
    client = KiwoomRESTClient(config_path=config_path)
    samsung_code = "005930"

    print("=" * 65)
    print(" [trading_bot] 삼성전자(005930) 키움 REST API 주가 조회 테스트")
    print("=" * 65)

    mode_str = "모의투자 (Mock)" if client.is_mock else "실전투자 (Real)"
    key_status = "설정됨 (유효함)" if client.is_credentials_valid() else "미설정 (API 키 확인 필요)"
    
    print(f"[*] 접속 환경 : {mode_str}")
    print(f"[*] API Key   : {key_status}")
    print("-" * 65)

    price_info = client.get_stock_price(samsung_code)

    if price_info.get("success"):
        sign = "+" if price_info['change'] > 0 else ""
        print(f"[-] 종목명    : {price_info['name']} ({price_info['code']})")
        print(f"[-] 현재가    : {price_info['current_price']:,} 원")
        print(f"[-] 전일대비  : {sign}{price_info['change']:,} 원 ({sign}{price_info['change_rate']}%)")
        print(f"[-] 전일 시가 : {price_info.get('prev_open_price', 0):,} 원")
        print(f"[-] 전일 고가 : {price_info.get('prev_high_price', 0):,} 원")
        print(f"[-] 전일 저가 : {price_info.get('prev_low_price', 0):,} 원")
        print(f"[-] 전일 종가 : {price_info.get('prev_close_price', 0):,} 원")
        print(f"[-] 당일 시가 : {price_info['open_price']:,} 원")
        print(f"[-] 당일 고가 : {price_info['high_price']:,} 원")
        print(f"[-] 당일 저가 : {price_info['low_price']:,} 원")
        print(f"[-] 당일 거래량: {price_info['volume']:,} 주")
    else:
        print(f"[X] 삼성전자 주가 조회 실패: {price_info.get('error')}")

    print("=" * 65)

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    # 1. 시각적 요약 출력
    print_samsung_price_summary()

    # 2. 단위 테스트 실행
    print("\n[단위 테스트 실행 결과]")
    unittest.main(argv=[sys.argv[0]], exit=False)
