"""
PythonAnywhere 및 WSGI 호환 웹 서버용 진입점 (WSGI Configuration File)
"""
import os
import sys

# 백엔드 디렉터리 경로 등록
base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

# uWSGI prefork 스레드 데드락 방지: worker 프로세스 내에서 지연 생성
_wsgi_app = None

def application(environ, start_response):
    global _wsgi_app
    environ['SCRIPT_NAME'] = ''
    if _wsgi_app is None:
        try:
            from main import app
            from a2wsgi import ASGIMiddleware
            _wsgi_app = ASGIMiddleware(app)
        except Exception as err:
            print(f"[wsgi.py] WSGI 로딩 예외: {err}")
            _wsgi_app = None


    if _wsgi_app is not None:
        return _wsgi_app(environ, start_response)

    status = '500 Internal Server Error'
    output = b'Error: WSGI Application failed to initialize.'
    response_headers = [('Content-type', 'text/plain; charset=utf-8'), ('Content-Length', str(len(output)))]
    start_response(status, response_headers)
    return [output]







