import os
import sys
import time
import asyncio


import json
import urllib.request
import websockets

base_url = "http://localhost:8000"
ws_url = "ws://localhost:8000/ws/trading"

async def test_websocket_stream():
    print("[1/2] WebSocket 실시간 스트리밍 접속 테스트...")
    async with websockets.connect(ws_url) as websocket:
        msg = await websocket.recv()
        data = json.loads(msg)
        print(f"  └─ WebSocket 데이터 수신 성공! 현재 상태: {data.get('status')}, 종목 수: {len(data.get('stocks', []))}")
        assert "status" in data
        assert "stocks" in data
        assert "unrealized_pnl" in data
        print("  └─ WebSocket 데이터 모델 구조 검증 완결!")

def test_rest_apis():
    print("[2/2] FastAPI REST API 종단간 테스트...")
    
    # 1. 상태 조회
    req = urllib.request.Request(f"{base_url}/api/status")
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"  └─ GET /api/status 성공! 대시보드 상태: {res.get('status')}")

    # 2. 신규 종목 추가 (3차시 진입 테스트)
    add_payload = {
        "code": "000660",
        "name": "SK하이닉스",
        "base_price": 180000,
        "clear_price": 210000,
        "num_steps": 20,
        "start_step": 3,
        "step_pct": 1.5,
        "budget_per_step": 200000,
        "memo": "3차시 진입 20차 그리드 테스트"
    }
    data_bytes = json.dumps(add_payload).encode("utf-8")
    req = urllib.request.Request(f"{base_url}/api/stocks", data=data_bytes, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"  └─ POST /api/stocks (3차시 진입 셋팅) 성공! 메시지: {res.get('message')}")

    # 3. 자동매매 체크박스 스위치 (OFF -> ON)
    toggle_payload = {"stock_code": "000660", "is_active": False}
    data_bytes = json.dumps(toggle_payload).encode("utf-8")
    req = urllib.request.Request(f"{base_url}/api/stocks/toggle-active", data=data_bytes, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"  └─ POST /api/stocks/toggle-active (OFF) 성공! 메시지: {res.get('message')}")

    # 6. 종목코드 <-> 종목명 양방향 자동 조회 테스트
    req = urllib.request.Request(f"{base_url}/api/stocks/lookup?code=005930")
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"  └─ GET /api/stocks/lookup (코드->이름) 성공! {res.get('code')} -> {res.get('name')}")
        assert res.get("name") == "삼성전자"

    # 7. 현재가 시세 조회 API 테스트
    req = urllib.request.Request(f"{base_url}/api/stocks/quote?code=005930")
    with urllib.request.urlopen(req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"  └─ GET /api/stocks/quote (현재가 시세) 성공! [{res.get('name')}] 현재가: {res.get('current_price'):,}원")
        assert res.get("current_price") > 0

    # 8. 자동매매 진행 중 삭제 차단 가드 및 종목 동시 삭제 검증
    # RUNNING 상태로 전환
    ctrl_payload = {"action": "START"}
    req = urllib.request.Request(f"{base_url}/api/control", data=json.dumps(ctrl_payload).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    urllib.request.urlopen(req)

    # RUNNING 상태에서 삭제 시도 -> HTTP 400 차단 확인
    try:
        del_req = urllib.request.Request(f"{base_url}/api/stocks/delete", data=json.dumps({"stock_code": "000660"}).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(del_req)
        assert False, "RUNNING 상태에서는 종목이 삭제되면 안 됨"
    except urllib.error.HTTPError as err:
        assert err.code == 400
        print("  └─ [안전 가드 통과] 자동매매 진행 중(RUNNING) 종목 삭제 차단 성공!")

    # STOP 상태로 전환 후 삭제
    ctrl_payload = {"action": "STOP"}
    req = urllib.request.Request(f"{base_url}/api/control", data=json.dumps(ctrl_payload).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    urllib.request.urlopen(req)

    # 종목 삭제 테스트 (SK하이닉스)
    del_req = urllib.request.Request(f"{base_url}/api/stocks/delete", data=json.dumps({"stock_code": "000660"}).encode("utf-8"), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(del_req) as resp:
        res = json.loads(resp.read().decode("utf-8"))
        print(f"  └─ POST /api/stocks/delete 성공! 메시지: {res.get('message')}")

    print("  └─ 모든 REST API 엔드포인트 검증 완료!")

if __name__ == "__main__":
    test_rest_apis()
    asyncio.run(test_websocket_stream())
    print("\n[SUCCESS] [MagicTrader Web Dashboard] 모든 백엔드 및 실시간 스트리밍 검증 통과!")
