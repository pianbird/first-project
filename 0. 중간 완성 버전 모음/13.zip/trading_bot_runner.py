"""
PythonAnywhere Always-on Task 전용 독립 자동매매 엔진 데몬 (trading_bot_runner.py)
- WSGI Web 대시보드(web_app/backend/main.py)와 완전 분리되어 24시간 독립 상주 구동
- shared SQLite DB(web_magictrader.db)를 통해 Web 대시보드의 제어 상태(RUNNING/STOPPED) 및 종목 그리드 설정을 실시간 동기화
- PythonAnywhere UTC 타임존 오차 보정: zoneinfo/timezone KST(Asia/Seoul, UTC+9) 적용
- 장 운영 시간 외에는 슬립 주기를 길게 조절하여 일일 CPU Quota 절약
"""
import os
import sys
import time
import datetime
import argparse

# 실행 디렉터리 및 web_app/backend 경로 등록
base_dir = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(base_dir, "web_app", "backend")

if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

try:
    from db import WebDBManager
    from engine import WebTradingEngine
    from reconciliation import AccountReconciler, ReconciliationError
except (ImportError, ModuleNotFoundError):
    from web_app.backend.db import WebDBManager
    from web_app.backend.engine import WebTradingEngine
    from trading_bot.reconciliation import AccountReconciler, ReconciliationError

def get_kst_now() -> datetime.datetime:
    """KST(Asia/Seoul, UTC+9) 현재 시각 반환 (PythonAnywhere UTC 서버 시차 보정)"""
    try:
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("Asia/Seoul"))
    except Exception:
        kst_tz = datetime.timezone(datetime.timedelta(hours=9))
        return datetime.datetime.now(kst_tz)

def get_kst_now_str() -> str:
    """KST 현재 시각 문자열 반환 (YYYY-MM-DD HH:MM:SS KST)"""
    return get_kst_now().strftime("%Y-%m-%d %H:%M:%S")

def is_korean_holiday(dt: datetime.datetime) -> bool:
    """한국 고정 공휴일 기본 체크 (1/1, 3/1, 5/5, 6/6, 8/15, 10/3, 10/9, 12/25 등)"""
    month_day = (dt.month, dt.day)
    fixed_holidays = [
        (1, 1),   # 신정
        (3, 1),   # 삼일절
        (5, 5),   # 어린이날
        (6, 6),   # 현충일
        (8, 15),  # 광복절
        (10, 3),  # 개천절
        (10, 9),  # 한글날
        (12, 25), # 성탄절
        (12, 31)  # 연말 휴장일
    ]
    return month_day in fixed_holidays

def is_market_hours() -> bool:
    """KST 한국 정규 주식 장 운영 시간 및 휴장일 체크 (평일 08:55 ~ 15:35 KST)"""
    now_kst = get_kst_now()
    if now_kst.weekday() >= 5:  # 토요일(5), 일요일(6)
        return False
    if is_korean_holiday(now_kst):
        return False
    current_time = now_kst.time()
    start_time = datetime.time(8, 55, 0)
    end_time = datetime.time(15, 35, 0)
    return start_time <= current_time <= end_time

def interruptible_sleep(db: WebDBManager, duration_sec: float, check_interval: float = 0.5):
    """긴 대기 중에도 DB의 engine_status 변경(RUNNING)을 0.5초 단위로 즉시 감지하여 빠른 반응성 제공"""
    elapsed = 0.0
    while elapsed < duration_sec:
        try:
            status_cfg = db.get_system_config("engine_status")
            if status_cfg and status_cfg.get("status") == "RUNNING":
                break
        except Exception:
            pass
        time.sleep(check_interval)
        elapsed += check_interval

def perform_startup_recovery(engine: WebTradingEngine, db: WebDBManager):
    """
    데몬 프로세스 시작/재시작 시 포지션 및 주문 상태 복구
    - AccountReconciler를 통해 키움 서버 잔고 및 미체결 주문을 조회하여 DB 상태와 비교 동기화
    - 불일치나 이상 발생 시 SAFE_STOP으로 보호
    """
    print(f"[{get_kst_now_str()} KST] 🔍 [Startup Recovery] 프로세스 재시작 잔고 및 미체결 주문 상태 복구 점검 시작...")
    if not engine.kiwoom_client or not engine.kiwoom_client.is_credentials_valid():
        print(f"[{get_kst_now_str()} KST] ℹ️ [Startup Recovery] 키움 인증키 미설정/가상 모드 상태입니다.")
        return

    try:
        # 1. AccountReconciler를 활용한 계좌 동기화 및 수량 대조 (Source of Truth)
        reconciler = AccountReconciler(db)
        is_ok, recon_info = reconciler.reconcile_account(engine.kiwoom_client, trading_mode=engine.trading_mode)

        if not is_ok:
            status_msg = recon_info.get("status", "RECONCILIATION_REQUIRED")
            mismatches = recon_info.get("mismatches", [])
            if mismatches:
                err_details = ", ".join([f"종목({m['stock_code']}): DB={m['db_qty']}주 vs 계좌={m['kiwoom_qty']}주" for m in mismatches])
                stop_msg = f"RECONCILIATION_REQUIRED: DB 포지션과 Kiwoom 계좌 수량 불일치 감지 ({err_details})"
                print(f"[{get_kst_now_str()} KST] 🚨 [Startup Recovery Mismatch SAFE_STOP] {stop_msg}")
                engine.trigger_safe_stop(stop_msg)
                return
            elif status_msg in ["QUERY_FAILED", "QUERY_EXCEPTION", "API_UNAVAILABLE"]:
                err_msg = recon_info.get("error", "잔고 조회 실패")
                print(f"[{get_kst_now_str()} KST] ⚠️ [Startup Recovery Warning] {err_msg}")
                db.add_log("WARNING", f"프로세스 재시작 잔고 확인 미완료: {err_msg}")
                return

        # 2. 계좌 잔고 DB 동기화
        kres = engine.get_kiwoom_positions(force_refresh=True)
        held = kres.get("positions") or kres.get("held_positions", []) if (kres and kres.get("success")) else []
        if held:
            db.sync_positions_to_db(held)
            print(f"[{get_kst_now_str()} KST] ✅ [Startup Recovery] 실제 계좌 잔고({len(held)}개 종목) Source of Truth 동기화 완료")

        # 3. UNKNOWN 주문 및 미체결 주문 상태 복구
        if hasattr(engine, "order_manager") and engine.order_manager and engine.kiwoom_client:
            resolved = engine.order_manager.resolve_unknown_orders(engine.kiwoom_client)
            if resolved > 0:
                print(f"[{get_kst_now_str()} KST] 🔧 [Startup Recovery] UNKNOWN 주문 {resolved}건 상태 확정 복구 완료")

        pending = db.get_pending_orders()
        if pending:
            print(f"[{get_kst_now_str()} KST] 📋 [Startup Recovery] 기존 미체결 주문 {len(pending)}건 상태 추적 유지")
        
        db.add_log("INFO", f"✅ [Startup Recovery] Always-on Task 재시작 후 포지션({len(held)}개) 상태가 복구되었습니다.")
    except Exception as e:
        err = f"프로세스 재시작 복구 중 예외 발생: {e}"
        print(f"[{get_kst_now_str()} KST] 🚨 [Startup Recovery Error] {err}")
        engine.trigger_safe_stop(err)

def run_trading_bot_daemon(interval: float = 2.5, run_once: bool = False):
    print("=" * 70)
    print(f" 🚀 [PythonAnywhere Always-on Task: MagicTrader 자동매매 엔진 데몬 시작] ({get_kst_now_str()} KST)")
    print("=" * 70)

    db = WebDBManager()
    engine = WebTradingEngine(db)

    # 프로세스 시작 시 계좌 상태 복구 수행
    perform_startup_recovery(engine, db)

    is_mock = True
    if engine.kiwoom_client and hasattr(engine.kiwoom_client, "is_mock"):
        is_mock = engine.kiwoom_client.is_mock
    env_name = "모의투자 (Mock)" if is_mock else "실전투자 (Real)"

    print(f"[*] 데이터베이스 경로 : {db.db_path}")
    print(f"[*] 키움 접속 환경    : {env_name}")
    print(f"[*] 초기 구동 상태    : {engine.status}")
    print(f"[*] 장중 평가 주기    : {interval}초 (KST 08:55~15:35 기준)")
    print("-" * 70)

    db.add_log("INFO", f"🚀 [Always-on Task] 백그라운드 자동매매 엔진 데몬이 구동되었습니다. ({get_kst_now_str()} KST)")
    last_hb_time = 0.0
    reconciler = AccountReconciler(db)
    cycle_counter = 0

    while True:
        try:
            now_ts = time.time()
            # 10초마다 Engine Heartbeat DB에 기록
            if now_ts - last_hb_time >= 10.0:
                db.update_heartbeat(
                    status=engine.status,
                    trading_mode=engine.trading_mode,
                    safe_stop_active=engine.safe_stop_active,
                    safe_stop_reason=engine.safe_stop_reason
                )
                last_hb_time = now_ts

            # Web 대시보드(WSGI)와 DB 제어 상태 및 종목 그리드 동기화
            if hasattr(engine, "sync_state_from_db"):
                engine.sync_state_from_db()
            else:
                status_cfg = db.get_system_config("engine_status")
                if status_cfg:
                    engine.status = status_cfg.get("status", engine.status)

            now_str = get_kst_now_str()
            in_market = is_market_hours()

            if engine.status == "RUNNING":
                if in_market:
                    engine.sync_market_prices()
                    engine.evaluate_grid_cycle()

                    # 60 사이클(약 2.5분)마다 계좌 정합성 주기적 재검증
                    cycle_counter += 1
                    if cycle_counter % 60 == 0 and engine.kiwoom_client and engine.kiwoom_client.is_credentials_valid():
                        is_ok, recon_info = reconciler.reconcile_account(engine.kiwoom_client, trading_mode=engine.trading_mode)
                        if not is_ok and recon_info.get("mismatches"):
                            err_details = ", ".join([f"종목({m['stock_code']}): DB={m['db_qty']}주 vs 계좌={m['kiwoom_qty']}주" for m in recon_info["mismatches"]])
                            stop_msg = f"RECONCILIATION_REQUIRED: 장중 계좌 잔고 수량 불일치 감지 ({err_details})"
                            engine.trigger_safe_stop(stop_msg)

                    print(f"[{now_str} KST] ⚡ [Always-on Task] 가동중 (RUNNING) | 장중 그리드 평가 완료")
                    sleep_time = interval
                else:
                    print(f"[{now_str} KST] 🌙 [Always-on Task] 가동중 (RUNNING) | 장외/휴장 시간 (CPU Quota 절약 15초 대기)")
                    sleep_time = 15.0
            elif engine.status == "SAFE_STOP":
                print(f"[{now_str} KST] 🚨 [Always-on Task] 비상 정지 (SAFE_STOP: {engine.safe_stop_reason}) | 주문이 안전 차단되었습니다.")
                sleep_time = 10.0
            else:
                print(f"[{now_str} KST] ⏸️ [Always-on Task] 대기중 (STOPPED) | 대시보드에서 '시작' 클릭 시 개시됩니다.")
                sleep_time = 5.0

            if run_once:
                print(f"[{now_str} KST] [Always-on Task] --once 옵션 1회 구동 완료.")
                break

            if sleep_time > 0.5:
                interruptible_sleep(db, sleep_time, check_interval=0.5)
            else:
                time.sleep(sleep_time)

        except KeyboardInterrupt:
            print(f"\n[{get_kst_now_str()} KST] [Always-on Task] 사용자에 의한 데몬 프로세스 종료 요청")
            db.add_log("WARNING", "⏹ [Always-on Task] 사용자에 의해 데몬 프로세스가 종료되었습니다.")
            break
        except Exception as err:
            err_msg = f"Always-on Task 루프 예외 발생: {err}"
            print(f"[{get_kst_now_str()} KST] [Always-on Task Error] {err_msg}")
            try:
                db.add_log("ERROR", err_msg)
            except Exception:
                pass
            time.sleep(5.0)

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    parser = argparse.ArgumentParser(description="MagicTrader Always-on Task Daemon Runner")
    parser.add_argument("--interval", type=float, default=2.5, help="Grid evaluation loop interval in seconds (default: 2.5)")
    parser.add_argument("--once", action="store_true", help="Run 1 cycle and exit (for verification)")
    args = parser.parse_args()

    run_trading_bot_daemon(interval=args.interval, run_once=args.once)
