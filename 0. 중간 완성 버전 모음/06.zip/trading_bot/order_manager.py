import time
from typing import Dict, Any, List, Optional
from db_manager import DBManager

class OrderStatus:
    PENDING = "PENDING"
    SUBMITTED = "SUBMITTED"
    ACCEPTED = "ACCEPTED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"

class OrderManager:
    """
    주문 상태 라이프사이클 및 미체결/UNKNOWN 상태 관리자
    - 주문 성공 = 체결 완료 간주 금지
    - 주문 접수(ACCEPTED)와 실제 체결(FILLED) 상태 명확히 구분 및 추적
    - 통신 단절 시 UNKNOWN 포착 후 미체결/잔고 조회를 통한 상태 확정
    """

    def __init__(self, db: DBManager):
        self.db = db

    def register_new_order(
        self,
        order_id: str,
        stock_code: str,
        stock_name: str,
        side: str,
        qty: int,
        price: int,
        order_type: str = "MARKET",
        initial_status: str = OrderStatus.SUBMITTED,
        message: str = ""
    ) -> Dict[str, Any]:
        """신규 주문 등록 및 DB 기록"""
        clean_code = str(stock_code).strip().zfill(6)
        order_info = {
            "order_id": order_id,
            "stock_code": clean_code,
            "stock_name": stock_name or clean_code,
            "side": side.upper(),
            "order_type": order_type,
            "requested_qty": qty,
            "filled_qty": 0,
            "remaining_qty": qty,
            "price": price,
            "status": initial_status,
            "message": message,
            "requested_at": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        self.db.save_order(order_info)
        return order_info

    def update_order_status(
        self,
        order_id: str,
        status: str,
        filled_qty: Optional[int] = None,
        message: str = ""
    ):
        """기존 주문 상태 갱신"""
        recent = self.db.get_recent_orders(limit=100)
        target = None
        for o in recent:
            if o.get("order_id") == order_id:
                target = o
                break

        if not target:
            return

        target["status"] = status
        if message:
            target["message"] = message
        if filled_qty is not None:
            target["filled_qty"] = filled_qty
            target["remaining_qty"] = max(0, target["requested_qty"] - filled_qty)

        self.db.save_order(target)

    def get_pending_orders(self, stock_code: Optional[str] = None) -> List[Dict[str, Any]]:
        return self.db.get_pending_orders(stock_code)

    def has_pending_order(self, stock_code: str) -> bool:
        pending = self.get_pending_orders(stock_code)
        return len(pending) > 0

    def resolve_unknown_orders(self, kiwoom_client: Any) -> int:
        """
        UNKNOWN 상태의 주문을 키움 미체결/잔고 API 조회를 통하여 최종 상태(ACCEPTED / FILLED / FAILED)로 확정
        :return: 확정 처리된 UNKNOWN 주문 건수
        """
        recent = self.db.get_recent_orders(limit=100)
        unknowns = [o for o in recent if o.get("status") == OrderStatus.UNKNOWN]

        if not unknowns:
            return 0

        resolved_count = 0
        try:
            held_list = []
            if kiwoom_client and hasattr(kiwoom_client, "is_credentials_valid") and kiwoom_client.is_credentials_valid():
                kpos_info = kiwoom_client.get_positions(force_refresh=True)
                held_list = kpos_info.get("held_positions", []) if isinstance(kpos_info, dict) else []
            else:
                db_positions = self.db.get_db_positions()
                held_list = [{"code": p["stock_code"], "qty": p["qty"]} for p in db_positions]

            for u_order in unknowns:
                ord_id = u_order.get("order_id")
                code = str(u_order.get("stock_code", "")).zfill(6)
                req_qty = u_order.get("requested_qty", 0)

                # 계좌 보유 수량 확인
                held_qty = 0
                for h in held_list:
                    if str(h.get("code") or h.get("stock_code", "")).zfill(6) == code:
                        held_qty = int(h.get("qty", 0))
                        break

                if held_qty >= req_qty:
                    self.update_order_status(ord_id, OrderStatus.FILLED, filled_qty=req_qty, message="UNKNOWN 상태 -> 체결(FILLED) 확정 복구")
                else:
                    self.update_order_status(ord_id, OrderStatus.FAILED, message="UNKNOWN 상태 -> 주문 불발(FAILED) 확정")
                resolved_count += 1
        except Exception as e:
            print(f"[resolve_unknown_orders 예외] {e}")

        return resolved_count
