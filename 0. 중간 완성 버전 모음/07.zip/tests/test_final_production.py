import os
import sys
import pytest
import tempfile
import json
import time

# Add project roots to sys.path
base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
bot_dir = os.path.join(base_dir, "trading_bot")
backend_dir = os.path.join(base_dir, "web_app", "backend")

for p in [base_dir, bot_dir, backend_dir]:
    if p not in sys.path:
        sys.path.insert(0, p)

from trading_mode import TradingModeManager, InvalidTradingModeError, ModeEndpointMismatchError, MODE_TEXT
from market_calendar import MarketCalendar
from reconciliation import AccountReconciler, ReconciliationError
from risk_manager import RiskManager
from order_manager import OrderManager, OrderStatus
from kiwoom_client import KiwoomRESTClient
from db import WebDBManager
from engine import WebTradingEngine

# Mock Kiwoom Client for testing
class MockKiwoomClient:
    def __init__(self, is_mock=True, fail_account=False, fail_quote=False, fail_order=False):
        self.is_mock = is_mock
        self.fail_account = fail_account
        self.fail_quote = fail_quote
        self.fail_order = fail_order
        self.config = {"account_no": "8133053801"}
        self.base_url = "https://mockapi.kiwoom.com" if is_mock else "https://api.kiwoom.com"
        self.app_key = "MOCK_KEY"
        self.app_secret = "MOCK_SECRET"

    def is_credentials_valid(self):
        return not self.fail_account

    def normalize_account_no(self, acc_str=None):
        return KiwoomRESTClient.normalize_account_no(acc_str)

    def get_masked_credentials(self):
        return {
            "configured": True,
            "trading_mode": "MOCK" if self.is_mock else "REAL",
            "app_key": "MOCK****",
            "account_no": "8133053801"
        }

    def get_positions(self, force_refresh=False):
        if self.fail_account:
            raise RuntimeError("ACCOUNT_QUERY_FAILED")
        return {
            "success": True,
            "held_positions": [
                {"code": "005930", "stock_code": "005930", "name": "삼성전자", "qty": 10, "avg_price": 70000}
            ]
        }

    def get_stock_price(self, code):
        if self.fail_quote:
            return {"success": False, "current_price": 0}
        return {"success": True, "current_price": 72000, "change": 2000, "change_rate": 2.85, "prev_close_price": 70000}

    def place_order(self, account_no, order_type, stock_code, qty, price=0, ord_dvsn="03"):
        if self.fail_order:
            raise RuntimeError("ORDER_NETWORK_TIMEOUT")
        return {
            "success": True,
            "order_id": f"ORD_MOCK_{int(time.time()*1000)}",
            "status": "ACCEPTED",
            "message": "Mock Order Accepted"
        }

# --- 1. Trading Mode Test ---
def test_trading_mode_validations():
    tm = TradingModeManager("MOCK")
    assert tm.get_mode() == "MOCK"
    assert tm.get_mode_text() == "모의투자"

    tm.set_mode("REAL")
    assert tm.get_mode() == "REAL"
    assert tm.get_mode_text() == "실전투자"

    tm.set_mode("DISABLED")
    assert tm.get_mode() == "DISABLED"
    assert tm.get_mode_text() == "매매중지"
    assert tm.can_place_order() is False

    with pytest.raises(InvalidTradingModeError):
        tm.set_mode("INVALID_MODE")

    with pytest.raises(InvalidTradingModeError):
        tm.set_mode("")

# --- 2. REAL/MOCK Endpoint Isolation Test ---
def test_mode_endpoint_isolation():
    tm = TradingModeManager("REAL")
    with pytest.raises(ModeEndpointMismatchError):
        tm.validate_endpoint_isolation("https://mockapi.kiwoom.com", is_mock_endpoint=True)

    tm_mock = TradingModeManager("MOCK")
    with pytest.raises(ModeEndpointMismatchError):
        tm_mock.validate_endpoint_isolation("https://openapi.kiwoom.com", is_mock_endpoint=False)

# --- 3. Account Failure -> SAFE_STOP Test ---
def test_account_failure_triggers_safe_stop(tmp_path):
    db_file = os.path.join(tmp_path, "test_recovery.db")
    db = WebDBManager(db_file)
    engine = WebTradingEngine(db)
    engine.trading_mode = "REAL"
    engine.kiwoom_client = MockKiwoomClient(is_mock=False, fail_account=True)

    reconciler = AccountReconciler(db)
    with pytest.raises(ReconciliationError):
        reconciler.reconcile_account(engine.kiwoom_client, trading_mode="REAL")

# --- 4. Quote Failure -> SAFE_STOP (No Naver Fallback in REAL) Test ---
def test_quote_failure_in_real_mode_triggers_safe_stop(tmp_path):
    db_file = os.path.join(tmp_path, "test_quote.db")
    db = WebDBManager(db_file)
    engine = WebTradingEngine(db)
    engine.trading_mode = "REAL"
    engine.stocks["005930"] = {
        "code": "005930", "name": "삼성전자", "clear_price": 80000,
        "memo": "", "grid": {}, "status": "TRACKING", "current_step": 0, "is_active": True
    }
    engine.kiwoom_client = MockKiwoomClient(is_mock=False, fail_quote=True)

    engine.sync_market_prices()
    assert engine.status == "SAFE_STOP"
    assert "REAL 모드" in engine.safe_stop_reason

# --- 5. Duplicate Order & Pending Order Check Test ---
def test_pending_and_duplicate_order_blocking(tmp_path):
    db_file = os.path.join(tmp_path, "test_order.db")
    db = WebDBManager(db_file)
    om = OrderManager(db, TradingModeManager("MOCK"))
    rm = RiskManager()
    kiwoom = MockKiwoomClient()

    # Submit first order
    res1 = om.submit_order(
        kiwoom_client=kiwoom, risk_manager=rm, account_no="8133053801",
        order_type="BUY", stock_code="005930", stock_name="삼성전자",
        qty=10, price=70000, ord_dvsn="01", strategy_id="TEST", cycle_id=1
    )
    assert res1.get("success") is True

    # Attempt duplicate order with same idempotency key
    res_dup = om.submit_order(
        kiwoom_client=kiwoom, risk_manager=rm, account_no="8133053801",
        order_type="BUY", stock_code="005930", stock_name="삼성전자",
        qty=10, price=70000, ord_dvsn="01", strategy_id="TEST", cycle_id=1
    )
    assert res_dup.get("success") is False
    assert "ORDER BLOCKED" in res_dup.get("message", "")

# --- 6. UNKNOWN Order Snapshot Resolution Test ---
def test_unknown_order_resolution(tmp_path):
    db_file = os.path.join(tmp_path, "test_unknown.db")
    db = WebDBManager(db_file)
    om = OrderManager(db, TradingModeManager("MOCK"))
    kiwoom = MockKiwoomClient(fail_order=True)

    # Order fails with network exception -> registered as UNKNOWN
    res = om.submit_order(
        kiwoom_client=kiwoom, risk_manager=None, account_no="8133053801",
        order_type="BUY", stock_code="005930", stock_name="삼성전자",
        qty=10, price=70000, ord_dvsn="01", strategy_id="TEST_UNK", cycle_id=100
    )
    assert res.get("status") == OrderStatus.UNKNOWN

    # Now fix Kiwoom mock and resolve UNKNOWN
    kiwoom_working = MockKiwoomClient(fail_order=False)
    resolved_cnt = om.resolve_unknown_orders(kiwoom_working)
    assert resolved_cnt >= 1

# --- 7. Security Credentials Masking Test ---
def test_credentials_masking():
    kc = KiwoomRESTClient()
    kc.app_key = "1234567890ABCDEF"
    masked = kc.get_masked_credentials()

    assert "app_secret" not in masked
    assert "access_token" not in masked
    assert masked["app_key"] == "1234****CDEF"

# --- 8. Codebase Order Path Audit Scan ---
def test_direct_place_order_scan():
    """Verify that place_order is only invoked inside order_manager.py or test files"""
    import re
    pattern = re.compile(r'\.place_order\(')
    direct_calls = []

    for root, dirs, files in os.walk(base_dir):
        # Exclude tests and pycache
        if "tests" in root or "__pycache__" in root or ".gemini" in root:
            continue
        for file in files:
            if file.endswith(".py") and file not in ("order_manager.py", "test_final_production.py"):
                filepath = os.path.join(root, file)
                with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                    for line_no, line in enumerate(f, 1):
                        if pattern.search(line):
                            direct_calls.append(f"{file}:{line_no} -> {line.strip()}")

    assert len(direct_calls) == 0, f"Found direct place_order calls outside order_manager.py: {direct_calls}"
