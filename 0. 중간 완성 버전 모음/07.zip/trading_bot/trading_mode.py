import os
from typing import Dict, Any, Optional

VALID_TRADING_MODES = {"MOCK", "REAL", "DISABLED"}

MODE_TEXT = {
    "MOCK": "모의투자",
    "REAL": "실전투자",
    "DISABLED": "매매중지"
}

class InvalidTradingModeError(ValueError):
    """트레이딩 모드가 유효하지 않을 때 발생하는 예외"""
    pass

class ModeEndpointMismatchError(RuntimeError):
    """REAL/MOCK 모드와 엔드포인트 URL이 불일치할 때 발생하는 예외"""
    pass

class TradingModeManager:
    """
    Trading Mode 중앙 관리 객체
    - MOCK, REAL, DISABLED 세 모드만 허용
    - 모드 변경 및 검증
    - REAL/MOCK 엔드포인트 수신 강제 점검
    - 주문 직전 최후 안전 Gate 검사
    """

    def __init__(self, initial_mode: str = "MOCK"):
        self.mode = self.validate_and_normalize_mode(initial_mode)

    @staticmethod
    def validate_and_normalize_mode(mode_input: Any) -> str:
        """
        트레이딩 모드 검증 및 정규화
        지원하는 모드: MOCK, REAL, DISABLED
        잘못된 값(TEST, INVALID, None, 빈문자열 등)은 거부
        """
        if not mode_input or not isinstance(mode_input, str):
            raise InvalidTradingModeError(f"유효하지 않은 트레이딩 모드 입력: {mode_input}")

        normalized = mode_input.strip().upper()
        if normalized not in VALID_TRADING_MODES:
            raise InvalidTradingModeError(
                f"지원하지 않는 트레이딩 모드입니다: '{mode_input}'. "
                f"허용된 모드: {sorted(list(VALID_TRADING_MODES))}"
            )

        return normalized

    def set_mode(self, new_mode: str) -> str:
        """모드 변경 (검증 포함)"""
        validated = self.validate_and_normalize_mode(new_mode)
        self.mode = validated
        return self.mode

    def get_mode(self) -> str:
        return self.mode

    def get_mode_text(self) -> str:
        """Dashboard 표시용 한국어 모드 명칭 반환 (NameError 방지)"""
        return MODE_TEXT.get(self.mode, "알 수 없음")

    def validate_endpoint_isolation(self, api_url: str, is_mock_endpoint: bool):
        """
        REAL/MOCK 서버 호환성 강제 검사
        - REAL 모드에서 mock 엔드포인트 사용 시 -> Fail & ModeEndpointMismatchError
        - MOCK 모드에서 real 엔드포인트 사용 시 -> Fail & ModeEndpointMismatchError
        """
        if self.mode == "DISABLED":
            return

        if self.mode == "REAL":
            if is_mock_endpoint or "mock" in api_url.lower() or "simulation" in api_url.lower():
                raise ModeEndpointMismatchError(
                    f"CRITICAL ERROR: REAL 모드에서 Mock API 엔드포인트({api_url})가 감지되었습니다. "
                    "실전 매매를 즉시 중단합니다."
                )

        if self.mode == "MOCK":
            if not is_mock_endpoint and ("openapi.kiwoom.com" in api_url.lower() and "mock" not in api_url.lower()):
                raise ModeEndpointMismatchError(
                    f"CRITICAL ERROR: MOCK 모드에서 REAL API 엔드포인트({api_url})가 감지되었습니다. "
                    "모의 매매를 즉시 중단합니다."
                )

    def can_place_order(self) -> bool:
        """주문 직전 매매 가능 여부 검사"""
        if self.mode == "DISABLED":
            return False
        return self.mode in ("MOCK", "REAL")
