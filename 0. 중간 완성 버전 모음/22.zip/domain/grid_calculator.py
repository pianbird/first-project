"""
Pure calculations for grid trading math and price normalization.
Preserves exact original rounding formulas: max(10, int(round(round(price) / 10.0)) * 10).
"""
from typing import List, Dict, Any

def get_tick_size(price: int) -> int:
    """
    국내 주식 시장 가격대별 호가 단위(Tick Size) 구하기 (2023년 개정 규칙 반영)
    """
    p = abs(int(price))
    if p < 2000:
        return 1
    elif p < 5000:
        return 5
    elif p < 20000:
        return 10
    elif p < 50000:
        return 50
    elif p < 200000:
        return 100
    elif p < 500000:
        return 500
    else:
        return 1000

def normalize_price(price: float) -> int:
    """
    주문 가격을 십원(10원) 단위 정수로 설정 (1원 단위 절삭 및 소수점 금액 삭제, 예: 2521 -> 2520)
    """
    if not price:
        return 0
    return max(10, int(round(round(float(price)) / 10.0)) * 10)

def calculate_grid_step_price(base_price: float, drop_pct: float) -> int:
    """
    기준가 대비 drop_pct% 하락 시 차수 목표 가격 계산 및 10원 단위 정규화
    """
    raw_price = base_price * (1.0 - (drop_pct / 100.0))
    return normalize_price(raw_price)

def generate_grid_steps(
    base_price: int,
    start_step: int = 1,
    steps_count: int = 10,
    step_drop_pct: float = 2.0,
    base_qty: int = 10
) -> List[Dict[str, Any]]:
    """
    차수별 목표가 및 누적 목표 수량 계산 (기존 그리드 자동 생성 알고리즘과 100% 동일)
    """
    steps = []
    accumulated_qty = 0
    
    for i in range(1, steps_count + 1):
        drop_multiplier = i - start_step
        if drop_multiplier < 0:
            step_price = base_price
        else:
            step_price = calculate_grid_step_price(base_price, drop_multiplier * step_drop_pct)

        # 차수별 수량 가중치 (1~3차: 1.0배, 4~6차: 1.5배, 7차 이상: 2.0배)
        if i <= 3:
            step_qty = int(base_qty * 1.0)
        elif i <= 6:
            step_qty = int(base_qty * 1.5)
        else:
            step_qty = int(base_qty * 2.0)

        accumulated_qty += step_qty
        steps.append({
            "step": i,
            "price": step_price,
            "target_qty": step_qty,
            "target_total_qty": accumulated_qty
        })
    return steps
