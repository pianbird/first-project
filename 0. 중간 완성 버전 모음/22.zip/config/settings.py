"""
Configuration loader and settings wrapper for MagicTrader.
"""
import os
import json
from typing import Dict, Any

class SystemSettings:
    """
    Unified settings loader reading from environment variables and config.json.
    Preserves exact key fallback structure.
    """
    def __init__(self, config_path: str = "trading_bot/config.json"):
        self.config_path = config_path
        self._data: Dict[str, Any] = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"[SystemSettings] Config load warning: {e}")
        return {}

    def get(self, key: str, default: Any = None) -> Any:
        # Environment variable override takes precedence
        env_val = os.getenv(key.upper())
        if env_val is not None:
            return env_val
        return self._data.get(key, default)
