"""
PythonAnywhere Always-on Task 전용 자동매매 엔진 데몬 호환용 진입점 (trading_bot/engine.py)
"""
import os
import sys

base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from always_on_daemon import run_always_on_engine

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="MagicTrader Always-on Task Daemon")
    parser.add_argument("--once", action="store_true", help="Run 1 cycle and exit (for verification test)")
    args = parser.parse_args()

    run_always_on_engine(run_once=args.once)

