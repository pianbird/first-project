"""
PythonAnywhere Always-on Task 전용 독립 자동매매 엔진 데몬 (trading_bot_runner.py)
- WSGI Web 대시보드(web_app/backend/main.py)와 완전 분리되어 24시간 독립 상주 구동
- shared SQLite DB(web_magictrader.db)를 통해 Web 대시보드의 제어 상태(RUNNING/STOPPED) 및 종목 그리드 설정을 실시간 동기화
- PythonAnywhere UTC 타임존 오차 보정: zoneinfo/timezone KST(Asia/Seoul, UTC+9) 적용
- 장 운영 시간 외에는 슬립 주기를 길게 조절하여 일일 CPU Quota 절약
"""
import os
import sys
import time
import datetime
import argparse

# 실행 디렉터리 및 web_app/backend 경로 등록
base_dir = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(base_dir, "web_app", "backend")

if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from db import WebDBManager
from engine import WebTradingEngine

def get_kst_now() -> datetime.datetime:
    """KST(Asia/Seoul, UTC+9) 현재 시각 반환 (PythonAnywhere UTC 서버 시차 보정)"""
    try:
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("Asia/Seoul"))
    except Exception:
        # zoneinfo 미지원 환경 폴백: UTC+9 explicit timezone
        kst_tz = datetime.timezone(datetime.timedelta(hours=9))
        return datetime.datetime.now(kst_tz)

def get_kst_now_str() -> str:
    """KST 현재 시각 문자열 반환 (YYYY-MM-DD HH:MM:SS KST)"""
    return get_kst_now().strftime("%Y-%m-%d %H:%M:%S")

def is_market_hours() -> bool:
    """KST 한국 정규 주식 장 운영 시간 체크 (평일 08:55 ~ 15:35 KST)"""
    now_kst = get_kst_now()
    if now_kst.weekday() >= 5:  # 토요일(5), 일요일(6)
        return False
    current_time = now_kst.time()
    start_time = datetime.time(8, 55, 0)
    end_time = datetime.time(15, 35, 0)
    return start_time <= current_time <= end_time

def run_trading_bot_daemon(interval: float = 2.5, run_once: bool = False):
    print("=" * 70)
    print(f" 🚀 [PythonAnywhere Always-on Task: MagicTrader 자동매매 엔진 데몬 시작] ({get_kst_now_str()} KST)")
    print("=" * 70)

    db = WebDBManager()
    engine = WebTradingEngine(db)

    is_mock = True
    if engine.kiwoom_client and hasattr(engine.kiwoom_client, "is_mock"):
        is_mock = engine.kiwoom_client.is_mock
    env_name = "모의투자 (Mock)" if is_mock else "실전투자 (Real)"

    print(f"[*] 데이터베이스 경로 : {db.db_path}")
    print(f"[*] 키움 접속 환경    : {env_name}")
    print(f"[*] 초기 구동 상태    : {engine.status}")
    print(f"[*] 장중 평가 주기    : {interval}초 (KST 08:55~15:35 기준)")
    print("-" * 70)

    db.add_log("INFO", f"🚀 [Always-on Task] 백그라운드 자동매매 엔진 데몬이 구동되었습니다. ({get_kst_now_str()} KST)")

    while True:
        try:
            # 1. Web 대시보드(WSGI)와 DB 제어 상태 및 종목 그리드 방어적 동기화
            if hasattr(engine, "sync_state_from_db"):
                engine.sync_state_from_db()
            else:
                status_cfg = db.get_system_config("engine_status")
                if status_cfg:
                    engine.status = status_cfg.get("status", engine.status)

            now_str = get_kst_now_str()
            in_market = is_market_hours()

            if engine.status == "RUNNING":
                if in_market:
                    engine.sync_market_prices()
                    engine.evaluate_grid_cycle()
                    print(f"[{now_str} KST] ⚡ [Always-on Task] 가동중 (RUNNING) | 장중 그리드 평가 완료")
                    sleep_time = interval
                else:
                    print(f"[{now_str} KST] 🌙 [Always-on Task] 가동중 (RUNNING) | 장외 시간 (CPU Quota 절약 15초 대기)")
                    sleep_time = 15.0
            else:
                print(f"[{now_str} KST] ⏸️ [Always-on Task] 대기중 (STOPPED) | 대시보드에서 '시작' 클릭 시 개시됩니다.")
                sleep_time = 5.0

            if run_once:
                print(f"[{now_str} KST] [Always-on Task] --once 옵션 1회 구동 완료.")
                break

            time.sleep(sleep_time)

        except KeyboardInterrupt:
            print(f"\n[{get_kst_now_str()} KST] [Always-on Task] 사용자에 의한 데몬 프로세스 종료 요청")
            db.add_log("WARNING", "⏹ [Always-on Task] 사용자에 의해 데몬 프로세스가 종료되었습니다.")
            break
        except Exception as err:
            err_msg = f"Always-on Task 루프 예외 발생: {err}"
            print(f"[{get_kst_now_str()} KST] [Always-on Task Error] {err_msg}")
            try:
                db.add_log("ERROR", err_msg)
            except Exception:
                pass
            time.sleep(5.0)

if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    parser = argparse.ArgumentParser(description="MagicTrader Always-on Task Daemon Runner")
    parser.add_argument("--interval", type=float, default=2.5, help="Grid evaluation loop interval in seconds (default: 2.5)")
    parser.add_argument("--once", action="store_true", help="Run 1 cycle and exit (for verification)")
    args = parser.parse_args()

    run_trading_bot_daemon(interval=args.interval, run_once=args.once)
