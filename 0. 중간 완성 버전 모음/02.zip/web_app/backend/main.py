import os
import sys
import time

from typing import List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse, Response



# backend 경로 모듈 등록
base_dir = os.path.dirname(os.path.abspath(__file__))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

from db import WebDBManager
from engine import WebTradingEngine
from models import (
    StockCreateRequest,
    SystemGuardConfig,
    ControlRequest,
    EmergencyResolutionRequest,
    ManualOrderRequest,
    StockToggleActiveRequest,
    StockDeleteRequest,
    KiwoomCredentialsRequest,
    ForceCloseRequest,
    TradingModeRequest
)

from stock_master import (
    lookup_stock_by_code,
    lookup_stock_by_name,
    search_stock_master,
    get_stock_price_quote
)


app = FastAPI(title="MagicTrader Web Dashboard Server", version="2.0.0")



# 데이터베이스 및 트레이딩 엔진 초기화
db = WebDBManager()
engine = WebTradingEngine(db)

# 프론트엔드 정적 파일 마운트
frontend_dir = os.path.join(os.path.dirname(base_dir), "frontend")
app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

# 연결된 WebSocket 클라이언트 관리자
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, data: dict):
        for connection in list(self.active_connections):
            try:
                await connection.send_json(data)
            except Exception:
                self.disconnect(connection)

ws_manager = ConnectionManager()

@app.get("/")
@app.get("/index.html")
async def serve_dashboard():
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            html_content = f.read()
        return HTMLResponse(content=html_content)
    return JSONResponse({"error": f"frontend/index.html 경로를 찾을 수 없습니다. (확인 경로: {index_path})"}, status_code=404)



@app.get("/api/status")
async def get_system_status():
    if engine.status == "RUNNING":
        engine.simulate_tick()
    return engine.get_full_dashboard_state()

@app.get("/api/stocks/search")
async def search_stocks(q: str = ""):
    matches = search_stock_master(q)
    return {"matches": matches}

@app.get("/api/stocks/lookup")
async def lookup_stock(code: str = None, name: str = None):
    if code:
        found_name = lookup_stock_by_code(code)
        if found_name:
            return {"success": True, "code": code.zfill(6), "name": found_name}
    if name:
        found_code = lookup_stock_by_name(name)
        if found_code:
            found_name = lookup_stock_by_code(found_code) or name
            return {"success": True, "code": found_code, "name": found_name}
    return {"success": False, "message": "종목 정보를 찾을 수 없습니다."}

@app.get("/api/stocks/quote")
async def get_stock_price_quote_api(code: str):
    clean_code = code.zfill(6)
    name = lookup_stock_by_code(clean_code) or clean_code
    price = get_stock_price_quote(clean_code)
    if clean_code in engine.market_data:
        price = engine.market_data[clean_code]["current_price"]
    suggested_clear = int(price * 1.015)
    suggested_clear = (suggested_clear // 100) * 100 if price >= 50000 else (suggested_clear // 10) * 10
    return {
        "success": True,
        "code": clean_code,
        "name": name,
        "current_price": price,
        "clear_price_suggested": suggested_clear
    }

@app.post("/api/stocks")
async def add_stock(req: StockCreateRequest):
    engine.add_stock(
        code=req.code,
        name=req.name,
        base_price=req.base_price,
        clear_price=req.clear_price,
        num_steps=req.num_steps,
        start_step=req.start_step,
        step_pct=req.step_pct,
        budget_per_step=req.budget_per_step,
        memo=req.memo or ""
    )
    return {"success": True, "message": f"종목 {req.name}({req.code}) [{req.start_step}차~{req.num_steps}차] 신규 등록 완료"}

@app.post("/api/stocks/toggle-active")
async def toggle_stock_active(req: StockToggleActiveRequest):
    ok = engine.toggle_stock_active(req.stock_code, req.is_active)
    if ok:
        status_text = "활성화" if req.is_active else "비활성화"
        return {"success": True, "message": f"종목({req.stock_code}) 자동매매 {status_text} 처리 완료"}
    raise HTTPException(status_code=404, detail="해당 종목을 찾을 수 없습니다.")

@app.post("/api/stocks/delete")
async def delete_stock(req: StockDeleteRequest):
    ok, msg = engine.delete_stock(req.stock_code)
    if ok:
        return {"success": True, "message": msg}
    raise HTTPException(status_code=400, detail=msg)

@app.post("/api/system/guard")
async def update_system_guard(cfg: SystemGuardConfig):
    engine.max_daily_trades = cfg.max_daily_trades
    engine.max_buy_amount = cfg.max_buy_amount
    engine.save_to_db()
    return {"success": True, "message": "리스크 가드 설정이 업데이트되었습니다."}

@app.get("/api/logs/download")
async def download_logs_api():
    """SQLite DB에 영속 저장된 실시간 매매 및 시스템 이력 로그 다운로드"""
    logs = engine.db.get_logs(limit=500)
    lines = [f"[{l['timestamp']}] [{l['level']}] {l['message']}" for l in reversed(logs)]
    content = "\n".join(lines)
    filename = f"magictrader_trade_logs_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    return Response(
        content=content,
        media_type="text/plain; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@app.post("/api/mode/set")
async def set_trading_mode_api(req: TradingModeRequest):
    res = engine.set_trading_mode("REAL")
    return res

@app.post("/api/mode/toggle")
async def toggle_trading_mode_api():
    res = engine.set_trading_mode("REAL")
    return res

@app.post("/api/control")
async def control_trading(req: ControlRequest):
    act = req.action.upper()
    if act == "START":
        engine.status = "RUNNING"
        engine.db.save_system_config("engine_status", {"status": "RUNNING"})
        engine.db.add_log("INFO", "▶ [자동매매 시작] 그리드 순환매매 엔진 구동을 개시합니다.")
    elif act == "STOP":
        engine.status = "STOPPED"
        engine.db.save_system_config("engine_status", {"status": "STOPPED"})
        engine.db.add_log("WARNING", "⏹ [자동매매 일시정지] 매매 엔진 구동이 중단되었습니다.")
    elif act == "CANCEL_ORDERS":
        if hasattr(engine, "cancel_all_pending_orders"):
            engine.cancel_all_pending_orders()
    else:
        raise HTTPException(status_code=400, detail="유효하지 않은 동작입니다.")
    return {"success": True, "status": engine.status}


@app.post("/api/db/save")
async def save_db():
    engine.save_to_db()
    # 백업도 동시 생성
    state = engine.get_full_dashboard_state()
    engine.db.create_backup(f"backup_{int(time.time())}", state)
    return {"success": True, "message": "데이터베이스 저장 및 백업 완결"}

@app.post("/api/db/load")
async def load_db():
    engine.load_from_db()
    return {"success": True, "message": "DB 데이터 로드 완결"}

@app.post("/api/db/backup")
async def load_backup():
    ok = engine.load_backup()
    if ok:
        return {"success": True, "message": "백업 복원 완료"}
    return {"success": False, "message": "복원할 백업 데이터가 존재하지 않습니다."}

@app.post("/api/db/reset")
async def reset_db_route():
    """데이터베이스 및 종목 그리드 설정 데이터 완전 초기화"""
    ok = engine.reset_db()
    if ok:
        return {"success": True, "message": "데이터베이스 및 그리드 설정 데이터가 성공적으로 초기화되었습니다."}
    raise HTTPException(status_code=500, detail="데이터베이스 초기화 처리 중 오류가 발생했습니다.")


@app.post("/api/emergency/resolve")
async def resolve_emergency(req: EmergencyResolutionRequest):
    ok = engine.resolve_emergency(req.stock_code, req.action_choice)
    if ok:
        return {"success": True, "message": "긴급 정지가 조치되었습니다."}
    raise HTTPException(status_code=404, detail="해당 종목을 찾을 수 없습니다.")

@app.post("/api/emergency/test-trigger")
async def trigger_emergency_test(stock_code: str = None):
    ok = engine.trigger_test_price_adjustment(stock_code)
    if ok:
        return {"success": True, "message": "권리락/무상증자 급락 테스트가 발령되었습니다."}
    raise HTTPException(status_code=400, detail="권리락 테스트 발령 실패")

@app.get("/api/kiwoom/positions")
async def get_kiwoom_positions_api():
    """키움증권 서버(또는 실시간 계좌) 보유 주식 정보 및 잔고 현황 조회"""
    data = engine.get_kiwoom_positions(force_refresh=True)
    return data

@app.get("/api/kiwoom/credentials")
async def get_kiwoom_credentials_api():
    """현재 저장된 키움 Open API 인증키 및 접속 설정 정보 조회"""
    return engine.get_kiwoom_credentials()

@app.post("/api/kiwoom/credentials")
async def update_kiwoom_credentials_api(req: KiwoomCredentialsRequest):
    """키움증권 Open API 인증키 (App Key / App Secret) 설정 업데이트 및 잔고 재조회"""
    raw_acc = (req.account_no or "81330538").strip()
    digits = "".join(filter(str.isdigit, raw_acc))
    acc_8 = digits[:8] if len(digits) >= 8 else "81330538"

    res = engine.update_kiwoom_credentials(
        app_key=req.app_key,
        app_secret=req.app_secret,
        account_no=acc_8,
        is_mock=req.is_mock if req.is_mock is not None else True
    )

    if res.get("success"):
        balance_res = engine.get_kiwoom_positions()
        return {
            "success": True,
            "message": res.get("message"),
            "balance": balance_res
        }
    raise HTTPException(status_code=400, detail=res.get("message", "인증키 설정 실패"))

@app.post("/api/orders/manual")
async def place_manual_order_api(req: ManualOrderRequest):
    """키움증권 서버 수동 매수/매도 주문 전송"""
    res = engine.execute_manual_order(
        stock_code=req.stock_code,
        order_type=req.order_type,
        qty=req.qty,
        price=req.price,
        ord_dvsn=req.ord_dvsn
    )
    if res.get("success"):
        return res
    raise HTTPException(status_code=400, detail=res.get("message", "주문 전송 실패"))

@app.post("/api/kiwoom/force-close")
async def force_close_api(req: ForceCloseRequest):
    """키움 계좌 보유 종목 시장가 강제청산 매도 주문 전송"""
    res = engine.force_close_kiwoom_position(
        stock_code=req.stock_code,
        qty=req.qty,
        stock_name=req.stock_name
    )
    if res.get("success"):
        return res
    raise HTTPException(status_code=400, detail=res.get("message", "강제청산 실패"))

@app.websocket("/ws/trading")
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        # 최초 접속 시 상태 즉시 전송
        await websocket.send_json(engine.get_full_dashboard_state())
        while True:
            # 수신 클라이언트 핑 무시/유지
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
    except Exception:
        ws_manager.disconnect(websocket)

@app.get("/{full_path:path}")
async def catch_all_frontend_routes(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(status_code=404, detail="요청하신 API 경로를 찾을 수 없습니다.")
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return JSONResponse({"error": "frontend/index.html 경로를 찾을 수 없습니다."}, status_code=404)

if __name__ == "__main__":

    try:
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000)
    except ImportError:
        print("Error: uvicorn 패키지가 설치되어 있지 않습니다.")
        print("로컬 테스트: pip install uvicorn fastapi a2wsgi 실행 후 다시 시도하세요.")
        print("PythonAnywhere: Web 탭의 WSGI 설정 파일에서 wsgi.py:application을 통해 웹 앱을 구동하세요.")

