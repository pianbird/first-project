import os
import json
import sqlite3
import time


from typing import Dict, Any, List, Optional

class WebDBManager:
    """
    MagicTrader Web Dashboard SQLite3 영속성 관리자
    """

    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            db_path = os.path.join(base_dir, "web_magictrader.db")

        self.db_path = db_path
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA busy_timeout=30000;")
        except Exception:
            pass
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # 1. 종목 및 그리드 설정 테이블
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS stock_grids (
                stock_code TEXT PRIMARY KEY,
                stock_name TEXT NOT NULL,
                clear_price INTEGER NOT NULL,
                memo TEXT DEFAULT '',
                grid_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """)

            # 2. 시스템 보조 설정 테이블
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS system_config (
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """)

            # 3. 데이터 백업 테이블
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                backup_name TEXT NOT NULL,
                backup_data TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            """)

            # 4. 체결 및 로그 테이블
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS web_trade_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                level TEXT NOT NULL,
                message TEXT NOT NULL
            )
            """)
            conn.commit()

    def save_stock_grid(self, code: str, name: str, clear_price: int, memo: str, grid_dict: Dict[str, Any]):
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        grid_json = json.dumps(grid_dict, ensure_ascii=False)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO stock_grids (stock_code, stock_name, clear_price, memo, grid_json, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (code, name, clear_price, memo, grid_json, now_str))
            conn.commit()

    def get_all_stock_grids(self) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM stock_grids")
            rows = cursor.fetchall()
            results = []
            for r in rows:
                results.append({
                    "stock_code": r["stock_code"],
                    "stock_name": r["stock_name"],
                    "clear_price": r["clear_price"],
                    "memo": r["memo"],
                    "grid": json.loads(r["grid_json"]),
                    "updated_at": r["updated_at"]
                })
            return results

    def delete_stock_grid(self, code: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM stock_grids WHERE stock_code = ?", (code,))
            conn.commit()

    def save_system_config(self, key: str, value_dict: Dict[str, Any]):
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        val_json = json.dumps(value_dict, ensure_ascii=False)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT OR REPLACE INTO system_config (key, value_json, updated_at)
            VALUES (?, ?, ?)
            """, (key, val_json, now_str))
            conn.commit()

    def get_system_config(self, key: str) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value_json FROM system_config WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                return json.loads(row["value_json"])
            return None

    def create_backup(self, backup_name: str, backup_dict: Dict[str, Any]):
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        data_json = json.dumps(backup_dict, ensure_ascii=False)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO backups (backup_name, backup_data, created_at)
            VALUES (?, ?, ?)
            """, (backup_name, data_json, now_str))
            conn.commit()

    def get_latest_backup(self) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT backup_data FROM backups ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            if row:
                return json.loads(row["backup_data"])
            return None

    def add_log(self, level: str, message: str):
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO web_trade_logs (timestamp, level, message)
            VALUES (?, ?, ?)
            """, (now_str, level, message))
            conn.commit()

    def get_logs(self, limit: int = 30) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM web_trade_logs ORDER BY id DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()
            return [{"id": r["id"], "timestamp": r["timestamp"], "level": r["level"], "message": r["message"]} for r in rows]

    def reset_database(self) -> bool:

        """데이터베이스 전체 초기화 (종목 그리드, 로그, 보조 설정 삭제)"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM stock_grids")
                cursor.execute("DELETE FROM system_config")
                cursor.execute("DELETE FROM web_trade_logs")
                conn.commit()
            self.add_log("WARNING", "🗑️ [DB 초기화] 데이터베이스 및 종목 그리드 설정 데이터가 성공적으로 초기화되었습니다.")
            return True
        except Exception as e:
            print(f"[WebDBManager reset_database 예외] {e}")
            return False

